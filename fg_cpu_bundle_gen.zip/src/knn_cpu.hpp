
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>
#ifdef _OPENMP
#include <omp.h>
#endif

// CPU brute-force kNN to produce successor next[i] = k-th nearest neighbor of i (excluding self).
// Complexity O(n^2 d), OpenMP-parallel over i.
inline std::vector<int32_t> kth_neighbor_successor_bruteforce(
    const float* X, int n, int d, int k)
{
    std::vector<int32_t> next(n, 0);

    #pragma omp parallel for schedule(static)
    for (int i=0; i<n; ++i) {
        std::vector<std::pair<float,int>> ds;
        ds.reserve(n-1);
        const float* xi = X + (size_t)i*d;
        for (int j=0; j<n; ++j) {
            if (j == i) continue;
            const float* xj = X + (size_t)j*d;
            float dist2 = 0.f;
            for (int t=0; t<d; ++t) {
                float dx = xi[t] - xj[t];
                dist2 += dx*dx;
            }
            ds.emplace_back(dist2, j);
        }
        std::nth_element(ds.begin(), ds.begin() + (k-1), ds.end(),
                         [](const auto& a, const auto& b){
                             if (a.first != b.first) return a.first < b.first;
                             return a.second < b.second;
                         });
        next[i] = ds[k-1].second;
    }
    return next;
}
